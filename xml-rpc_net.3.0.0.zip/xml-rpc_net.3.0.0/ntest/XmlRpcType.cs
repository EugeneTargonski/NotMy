﻿using CookComputing.XmlRpc;
using NUnit.Framework;

namespace ntest
{
  class XmlRpcTypeTest
  {

  }
}
