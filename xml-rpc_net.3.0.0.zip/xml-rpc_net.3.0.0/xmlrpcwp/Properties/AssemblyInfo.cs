﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("XML-RPC.NET for Windows Phone")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Cook Computing")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright © Charles Cook 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

